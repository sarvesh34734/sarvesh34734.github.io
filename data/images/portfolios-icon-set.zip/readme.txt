Thanks for downloading this file.

This icon set was brought to you by MediaLoot.com and SmashingMagazine.com.

You can use it for both your personal and commercial projects, including software, web apps and online services.

The icons may not be resold or sublicensed. This icon set may not be made available for download on websites other than MediaLoot.com and SmashingMagazine.com.

Please link to the URL on MediaLoot.com or SmashingMagazine.com if you'd like to spread the word about this icon set.

www.medialoot.com
www.smashingmagazine.com
